#!/usr/bin/env python3
import json
import sys
import traceback

from ectf25.utils.decoder import DecoderIntf
from loguru import logger


def conn():
    r = DecoderIntf(sys.argv[1], timeout=5, write_timeout=5)

    return r


def nop(r: DecoderIntf):
    print(r.decode(bytes.fromhex(frames[0]["encoded"])))
    print(r.decode(bytes.fromhex(frames[1]["encoded"])))


def main():
    r = conn()
    global frames
    frames = [{"channel": 1, "timestamp": 1742323413465982, "encoded": "010000007ebb2448a23006006e6f666c61676f6e746869736368616e5e20666c6167205e303030363330613234383234626237655e2074696d65205e33363732376634383435633638626538"}, {
        "channel": 1, "timestamp": 1742323413967311, "encoded": "01000000cf612c48a23006006e6f666c61676f6e746869736368616e5e20666c6167205e303030363330613234383263363163665e2074696d65205e63653238363233383239356536303364"}]

    attacks = [nop]
    for attack in attacks:
        logger.info(f"Running {attack.__name__}")
        try:
            attack(r)
        except Exception:
            traceback.print_exc()


if __name__ == "__main__":
    main()
